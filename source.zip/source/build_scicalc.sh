#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RESOURCE_BIN=${1:-${HOME}/resource.bin}
if [ "$#" -ge 2 ]; then
    OUTPUT=$2
else
    VERSION=2
    while [ -e "$ROOT/SciCalc_Apple_UI_v${VERSION}.bin" ] ||
          [ -e "$ROOT/SciCalc_v${VERSION}.bin" ]; do
        VERSION=$((VERSION + 1))
    done
    OUTPUT="$ROOT/SciCalc_v${VERSION}.bin"
fi
BUILD_DIR="$ROOT/build/scicalc"
mkdir -p "$BUILD_DIR"

if [ ! -f "$RESOURCE_BIN" ]; then
    printf 'Resource template not found: %s\nUsage: %s [resource.bin] [output.bin]\n' \
        "$RESOURCE_BIN" "$0" >&2
    exit 1
fi

ELF_PATH="$BUILD_DIR/mb10p_sci_3.201.016.elf"
ELF_CAPACITY=19523
build_elf() {
    clang --target=arm-none-eabi \
        -mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 \
        -ffreestanding -fno-common -fno-builtin -nostdlib \
        -fno-jump-tables -fno-stack-protector -fno-unwind-tables \
        -fno-asynchronous-unwind-tables -fdata-sections -fno-function-sections \
        -fno-ident \
        "$1" -I"$ROOT" -I"$ROOT/mb10pro" -DMB10P_FW_VERSION=3201016 \
        -Wall -Wextra -Werror \
        -c "$ROOT/mb10pro/mb10p_sci.c" -o "$BUILD_DIR/mb10p_sci.o"

    ld.lld -r --discard-all -T "$ROOT/mb10pro/mb10pro.ld" \
        -o "$ELF_PATH" "$BUILD_DIR/mb10p_sci.o"
}

build_elf -Os
ELF_SIZE=$(wc -c < "$ELF_PATH")
if [ "$ELF_SIZE" -gt "$ELF_CAPACITY" ]; then
    printf 'SciCalc ELF is %s bytes; retrying with -Oz\n' "$ELF_SIZE"
    build_elf -Oz
    ELF_SIZE=$(wc -c < "$ELF_PATH")
fi

if [ "$ELF_SIZE" -gt "$ELF_CAPACITY" ]; then
    printf 'SciCalc ELF is %s bytes; resource slot capacity is %s bytes\n' \
        "$ELF_SIZE" "$ELF_CAPACITY" >&2
    exit 1
fi

python3 "$ROOT/tools/repack_resource.py" \
    "$RESOURCE_BIN" "$OUTPUT" \
    "0=lua/mb10p_sci_3.201.016.elf:$ELF_PATH" \
    "1=lua/main.lua:$ROOT/mb10pro/wf_native_sci/app/lua/main.lua" \
    "2=lua/calc_logo_112.png:$ROOT/mb10pro/wf_native_sci/app/lua/calc_logo_112.png"

printf 'Built %s (%s-byte ARM ELF; firmware 3.201.016)\n' "$OUTPUT" "$ELF_SIZE"

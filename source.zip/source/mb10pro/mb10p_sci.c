/* mb10p_sci.c -- Kalkulator ilmiah (mesin desimal 40 digit di sci_engine.h) */
#include <stdint.h>
#include "common/misc/mem.h"
#include "platform/miwear_system.h"
#include "common/miwear/app.h"
#include "common/miwear/watchface.h"
#include "common/lvgl/control.h"
#include "sci_engine.h"

#define APP_TAG      "com.user.sci"
#define SCI_APP_ID   0xC3u
#define SCI_PAGE_ID  0x00u
#define APP_NAME     APP_TAG
#define PAGE_NAME    "main"

/* Kode event LVGL: CLICKED=7 terverifikasi (dipakai Notes/Calc). PRESSED=1,
 * PRESS_LOST=3, RELEASED=8 mengikuti enum LVGL 8/9.0 yang sama. Umpan balik
 * tekan hanya mengubah warna SATU tombol; teks tombol tidak pernah disentuh
 * saat ditekan, jadi tidak ada teks yang bergeser/berkedip. */
#define EV_PRESSED    1u
#define EV_PRESS_LOST 3u
#define EV_CLICKED    7u
#define EV_RELEASED   8u

#define SCREEN_W  336
#define SCREEN_H  480
#define BTN_W     76
#define BTN_H     66
#define BTN_GAP   4
#define GRID_X    10
#define GRID_Y    112
#define NKEYS     20
#define NPAGES    3
#define EXPR_MAX  72
#define SHOW_MAX  10   /* ekspresi kecil sejajar angka besar, kiri; muat ~10 karakter */
#define RESULT_Y  28
#define RESULT_H  54
#define RESULT_DEL_W 42
#define RESULT_DEL_H 34
#define RESULT_DEL_X (SCREEN_W - 14 - RESULT_DEL_W)
#define RESULT_DEL_Y (RESULT_Y + (RESULT_H - RESULT_DEL_H) / 2 - 6)
#define FADE_PERIOD 35

/* Garis outline di sekeliling layar = tepi container bawaan jam, bukan bagian
 * app. Root diperbesar OUTSET px ke tiap sisi supaya menutupinya (isi tetap di
 * posisi semula). Kalau garis masih terlihat, naikkan: OUTSET=20 sh sci_build.sh
 * (flag -D belum diteruskan build.sh, edit angka ini langsung). */
#ifndef OUTSET
#define OUTSET    14
#endif
#ifndef REMOVE_MS
#define REMOVE_MS 4500   /* + 500 ms timer awal = ~5 dtk setelah insmod */
#endif
#define FLAG_SCROLLABLE 0x10u   /* LV_OBJ_FLAG_SCROLLABLE = 1<<4 (LVGL 8 dan 9) */
#define FLAG_CLICKABLE  0x02u

/* Dark keypad with orange reserved for arithmetic operators. */
#define COL_BG    0x000000u
#define COL_NUM   0x303034u
#define COL_TOP   0x68686Du
#define COL_OP    0xFF9500u
#define COL_SCI   0x242427u
#define COL_LINE  0x444448u
#define COL_PILL  0x606065u
#define COL_HOME  0xB8B8BCu

/* STYLE_1 is the only verified large-result style on this firmware. */
#ifndef BIGSTYLE
#define BIGSTYLE 1
#endif
#define STYLE_ADDR(n) ((n) == 3 ? LB_TEXT_STYLE_3 : (n) == 2 ? LB_TEXT_STYLE_2 : LB_TEXT_STYLE_1)
#ifndef BIG_MAX
#define BIG_MAX   10   /* keep the large readout short enough for the watch's system font */
#endif

/* Three fixed 4x5 pages; scientific equals spans the last three right-column rows. */
static const char KEYS[] =
    "C~#C|±~#SGN|%~#PCT|÷~/|7|8|9|×~*|4|5|6|−~-|1|2|3|+|0||.|=~#EQ|"
    "Nxt~#NX|@sin|@cos|@tan|asn~asin(|acs~acos(|atn~atan(|@ln|@log|"
    "sqr~sqrt(|e^x~exp(|=~#EQ|10x~10^(|x^2~^2|1/x~^(-1)||n!~!|(|)||"
    "PRV~#PV|snh~sinh(|csh~cosh(|tnh~tanh(|ash~asinh(|ach~acosh(|ath~atanh(|"
    "Ans|pi|e|^|=~#EQ|EXP~E|D/R~#DR|M+~#M+||M-~#M-|MR~#MR|MC~#MC||";

__attribute__((used)) static void *post_timer_id;

static char g_expr[EXPR_MAX + 1];
static int  g_len, g_page, g_dm = 1, g_done;
static char g_res[40];
static dec  g_mem;
static int  g_mem_set;
static char g_body[200];
static int  g_blen;
static lv_obj_t *g_lbl[3];            /* status, ekspresi, hasil */
static lv_obj_t *g_btn[NKEYS];
static int  g_shown = -1;             /* halaman yang teks tombolnya sudah terpasang */
static lv_obj_t *g_deg_label;
static lv_obj_t *g_deg_pill;
static lv_obj_t *g_deg_pill_inner;
static lv_obj_t *g_page_dots[3];
static lv_obj_t *g_result_del;
static void *g_fade_timer;

/* ---- helper string (tanpa libc) ---- */
static int slen(const char *s) { int n = 0; while (s[n]) n++; return n; }

static void copy_text(char *dst, int cap, const char *src)
{
    int i = 0;
    while (src[i] && i < cap - 1) { dst[i] = src[i]; i++; }
    dst[i] = 0;
}

static void b_chr(char c)
{
    if (g_blen < (int)sizeof(g_body) - 1) { g_body[g_blen++] = c; g_body[g_blen] = 0; }
}
static void b_str(const char *s) { while (*s) b_chr(*s++); }

/* tulis g_body ke label n lalu kosongkan buffer */
static void lbl_flush(int n)
{
    if (g_lbl[n]) lv_label_set_text(g_lbl[n], g_body);
    g_blen = 0; g_body[0] = 0;
}

static void res_set(const char *s) { copy_text(g_res, sizeof g_res, s); }

static void result_fade_stop(void)
{
    if (g_fade_timer) {
        lv_timer_delete(g_fade_timer);
        g_fade_timer = 0;
        lvx_obj_set_style_text(g_lbl[2], (lv_style_t *)STYLE_ADDR(BIGSTYLE), 255, 0);
    }
}

static void result_fade_tick(lv_timer_t *timer)
{
    (void)timer;
    lvx_obj_set_style_text(g_lbl[2], (lv_style_t *)STYLE_ADDR(BIGSTYLE), 255, 0);
    lv_timer_delete(g_fade_timer);
    g_fade_timer = 0;
}

static void result_fade_start(void)
{
    lvx_obj_set_style_text(g_lbl[2], (lv_style_t *)STYLE_ADDR(BIGSTYLE), 96, 0);
    g_fade_timer = lv_timer_create(result_fade_tick, FADE_PERIOD, 0);
    if (!g_fade_timer)
        lvx_obj_set_style_text(g_lbl[2], (lv_style_t *)STYLE_ADDR(BIGSTYLE), 255, 0);
}

static void scicalc_pill_paint(int pressed)
{
    lv_obj_set_style_bg_color(g_deg_pill, pressed ? COL_HOME : COL_PILL, 0);
    lv_obj_set_style_bg_color(g_deg_pill_inner, pressed ? COL_HOME : COL_BG, 0);
}

/* ---- tombol ---- */
/* ambil label & aksi tombol i di halaman aktif (buffer >= 8 byte) */
static void key_get(int i, char *lbl, char *act)
{
    const char *p = KEYS;
    int n = g_page * NKEYS + i, l = 0, a = 0, has = 0, fn;
    while (n--) { while (*p != '|') p++; p++; }
    fn = (*p == '@');
    if (fn) p++;
    for (; *p != '|'; p++) {
        if (*p == '~') has = 1;
        else if (has) act[a++] = *p;
        else lbl[l++] = *p;
    }
    if (!has) for (a = 0; a < l; a++) act[a] = lbl[a];
    if (fn) act[a++] = '(';
    lbl[l] = 0; act[a] = 0;
    if (act[0] == '#' && ((act[1] == 'N' && act[2] == 'X') ||
                          (act[1] == 'P' && act[2] == 'V')))
        copy_text(lbl, 8, g_page == 1 ? ">" : "<");
}

static uint32_t key_col(const char *a, const char *l)
{
    char c = a[0];
    (void)l;
    if (c == 0) return COL_BG;
    if (c == '#') {
        if (a[1] == 'E') return COL_OP;                        /* = */
        if (a[1] == 'C' || (a[1] == 'D' && a[2] == 'E') ||
            (a[1] == 'S' && a[2] == 'G') || (a[1] == 'P' && a[2] == 'C'))
            return COL_TOP;
        if (a[1] == 'B' || (a[1] == 'N' && a[2] == 'X') ||
            (a[1] == 'P' && a[2] == 'V') || a[1] == 'S')
            return COL_TOP;
        return COL_SCI;
    }
    if (a[1] == 0 && (c == '+' || c == '-' || c == '*' || c == '/')) return COL_OP;
    if (a[1] == 0 && c >= '0' && c <= '9') return COL_NUM;
    return COL_SCI;
}

/* cerahkan tiap kanal 25% menuju putih (tanpa overflow antar kanal) */
static uint32_t lift(uint32_t c) { return c + ((~c >> 2) & 0x3F3F3Fu); }

/* warna tombol i; down != 0 = sedang ditekan */
static void key_paint(int i, int down)
{
    char l[8], a[8];
    uint32_t c;
    if (i < 0 || g_btn[i] == 0) return;
    key_get(i, l, a);
    c = key_col(a, l);
    if (down && c != COL_BG) c = lift(c);
    lvx_btn_set_style_bg_color(g_btn[i], c);
}

/* teks tombol hanya dipasang saat halaman berganti, tidak pernah saat ditekan */
static void keys_sync(void)
{
    int i;
    char l[8], a[8];
    if (g_shown == g_page) return;
    for (i = 0; i < NKEYS; i++) {
        if (g_btn[i] == 0) continue;
        key_get(i, l, a);
        if (g_page == 0 && i == 16) {
            lv_obj_set_size(g_btn[i], BTN_W * 2 + BTN_GAP, BTN_H);
        } else if (g_page > 0 && i == 11) {
            lv_obj_set_size(g_btn[i], BTN_W, BTN_H * 3 + BTN_GAP * 2);
        } else {
            lv_obj_set_size(g_btn[i], BTN_W, BTN_H);
        }
        lv_obj_align(g_btn[i], LV_ALIGN_TOP_LEFT,
                     OUTSET + GRID_X + (i % 4) * (BTN_W + BTN_GAP),
                     OUTSET + GRID_Y + (i / 4) * (BTN_H + BTN_GAP));
        if (l[0]) lv_obj_add_flag(g_btn[i], FLAG_CLICKABLE);
        else {
            lv_obj_clear_flag(g_btn[i], FLAG_CLICKABLE);
            lv_obj_set_size(g_btn[i], 1, 1);
            lv_obj_align(g_btn[i], LV_ALIGN_TOP_LEFT, OUTSET, OUTSET);
        }
        lvx_btn_set_text_fmt(g_btn[i], l);
        key_paint(i, 0);
    }
    g_shown = g_page;
}

/* ---- tampilan ---- */
static void render(void)
{
    int start;
    scicalc_pill_paint(0);
    if (g_mem_set) b_str(g_page ? "  M" : "M");
    lbl_flush(0);
    lv_label_set_text(g_deg_label, "SciCalc");
    /* baris kecil: ekspresi (setelah hasil, error, atau jika terlalu panjang) */
    if (g_done || g_res[0]) {
        start = g_len > SHOW_MAX ? g_len - SHOW_MAX : 0;
        if (start > 0) b_str("..");
        b_str(g_expr + start);
    }
    lbl_flush(1);
    /* baris besar: hasil, atau yang sedang diketik */
    if (g_res[0]) b_str(g_res);
    else if (g_len == 0) b_chr('0');
    else {
        start = g_len > BIG_MAX ? g_len - BIG_MAX : 0;
        if (start > 0) b_str("..");
        b_str(g_expr + start);
    }
    lbl_flush(2);
    result_fade_start();
    for (start = 0; start < 3; start++)
        lvx_btn_set_style_bg_color(g_page_dots[start],
                                   start == g_page ? COL_HOME : COL_LINE);
    keys_sync();
}

/* ---- logika ---- */
static void clear_all(void)
{
    g_len = 0; g_expr[0] = 0; g_res[0] = 0; g_done = 0;
}

static void insert(const char *t)
{
    int n = slen(t), i;
    if (g_done) {
        char c = t[0];
        if (c == '+' || c == '-' || c == '*' || c == '/' || c == '^' || c == '!' || c == '%') {
            copy_text(g_expr, EXPR_MAX + 1, "Ans"); g_len = 3;
        } else {
            g_len = 0; g_expr[0] = 0;
        }
        g_done = 0;
    }
    g_res[0] = 0;
    if (g_len + n > EXPR_MAX) { res_set("Too long"); return; }
    for (i = 0; i < n; i++) g_expr[g_len++] = t[i];
    g_expr[g_len] = 0;
}

static int is_lc(char c) { return (c >= 'a' && c <= 'z') || c == 'A'; }

static void do_del(void)
{
    g_done = 0; g_res[0] = 0;
    if (g_len == 0) return;
    if (g_expr[g_len - 1] == '(') {
        g_len--;
        while (g_len > 0 && is_lc(g_expr[g_len - 1])) g_len--;
    } else if (is_lc(g_expr[g_len - 1])) {
        while (g_len > 0 && is_lc(g_expr[g_len - 1])) g_len--;
    } else {
        g_len--;
    }
    g_expr[g_len] = 0;
}

static int atom_start(void)
{
    int start = g_len, depth = 0;
    if (start == 0) return 0;
    if (g_expr[start - 1] == ')') {
        int i;
        for (i = start - 1; i >= 0; i--) {
            if (g_expr[i] == ')') depth++;
            else if (g_expr[i] == '(' && --depth == 0) {
                start = i;
                break;
            }
        }
        while (start > 0 && is_lc(g_expr[start - 1])) start--;
    } else {
        while (start > 0) {
            char c = g_expr[start - 1];
            if ((c >= '0' && c <= '9') || is_lc(c) || c == '.') start--;
            else if ((c == '+' || c == '-') && start > 1 && g_expr[start - 2] == 'E')
                start--;
            else break;
        }
    }
    return start;
}

static void toggle_sign(void)
{
    int start, i;
    g_res[0] = 0;
    g_done = 0;
    if (g_len == 0) {
        insert("-");
        return;
    }
    {
        char last = g_expr[g_len - 1];
        if (last == '+' || last == '-' || last == '*' || last == '/' || last == '^') {
            if (last != '-') insert("-");
            return;
        }
    }
    start = atom_start();
    if (start > 0 && g_expr[start] != '(' && g_expr[start - 1] == '-' &&
        (start == 1 || g_expr[start - 2] == '+' || g_expr[start - 2] == '-' ||
         g_expr[start - 2] == '*' || g_expr[start - 2] == '/' ||
         g_expr[start - 2] == '^' || g_expr[start - 2] == '(')) {
        for (i = start - 1; i < g_len - 1; i++) g_expr[i] = g_expr[i + 1];
        g_len--;
        g_expr[g_len] = 0;
        return;
    }
    if (start > 0 && (g_expr[start - 1] == '+' || g_expr[start - 1] == '-') &&
        start > 1 && (is_digit(g_expr[start - 2]) || g_expr[start - 2] == ')' ||
                      is_lc(g_expr[start - 2]))) {
        g_expr[start - 1] = g_expr[start - 1] == '+' ? '-' : '+';
    } else if (start >= 1 && g_expr[start - 1] == '-' && g_expr[start] == '(' &&
               g_expr[g_len - 1] == ')' &&
               (start == 1 || g_expr[start - 2] == '+' || g_expr[start - 2] == '-' ||
                g_expr[start - 2] == '*' || g_expr[start - 2] == '/' ||
                g_expr[start - 2] == '^' || g_expr[start - 2] == '(')) {
        for (i = start - 1; i < g_len - 3; i++) g_expr[i] = g_expr[i + 2];
        g_len -= 3;
        g_expr[g_len] = 0;
    } else if (g_len + 3 <= EXPR_MAX) {
        for (i = g_len; i > start; i--) g_expr[i + 1] = g_expr[i - 1];
        g_expr[start] = '-';
        g_expr[start + 1] = '(';
        g_expr[g_len + 2] = ')';
        g_len += 3;
        g_expr[g_len] = 0;
    }
}

static const char *err_text(int e)
{
    return e == ERR_MATH ? "Math Err" : e == ERR_OVER ? "Overflow" :
           e == ERR_DEEP ? "Too deep" : "Syntax Err";
}

static void do_eval(void)
{
    dec r;
    int e;
    if (g_len == 0 || g_done) return;
    e = sci_eval(g_expr, &r, g_dm);
    if (e == ERR_NONE) {
        d_fmt(&r, g_res, 8);
        d_cp(&g_ans, &r);
        g_done = 1;
    } else {
        res_set(err_text(e));
    }
}

static void memory_add(int subtract)
{
    dec v;
    int e;
    if (g_len == 0) { res_set("No expr"); return; }
    e = sci_eval(g_expr, &v, g_dm);
    if (e != ERR_NONE) { res_set(err_text(e)); return; }
    if (!g_mem_set) d_clr(&g_mem);
    if (subtract) d_sub(&g_mem, &g_mem, &v); else d_add(&g_mem, &g_mem, &v);
    g_mem_set = 1;
    res_set(subtract ? "M-" : "M+");
}

static void memory_recall(void)
{
    char value[40], token[42];
    int i = 0, n;
    if (!g_mem_set) { res_set("Mem empty"); return; }
    d_fmt(&g_mem, value, 8);
    token[i++] = '(';
    for (n = 0; value[n]; n++) token[i++] = value[n];
    token[i++] = ')';
    token[i] = 0;
    insert(token);
}

static void on_key(int i)
{
    char l[8], a[8];
    result_fade_stop();
    key_get(i, l, a);
    if (a[0] == '#') {
        char c = a[1], d = a[2];
        if (c == 'S' && d == 'G') toggle_sign();
        else if (c == 'P' && d == 'C') insert("%");
        else if (c == 'S') g_page = 1;
        else if (c == 'B') g_page = 0;
        else if (c == 'N' && d == 'X') g_page = 2;
        else if (c == 'P' && d == 'V') g_page = 1;
        else if (c == 'C') clear_all();
        else if (c == 'D' && d == 'E') do_del();
        else if (c == 'D') g_dm = !g_dm;
        else if (c == 'E') do_eval();
        else if (c == 'M' && d == '+') memory_add(0);
        else if (c == 'M' && d == '-') memory_add(1);
        else if (c == 'M' && d == 'R') memory_recall();
        else if (c == 'M') { g_mem_set = 0; res_set("MC"); }
    } else if (a[0]) {
        insert(a);
        g_page = 0;
    }
    render();
}

static void on_page_dot(lv_event_t *e)
{
    g_page = (int)(uintptr_t)lv_event_get_user_data(e);
    result_fade_stop();
    render();
}

static void on_scicalc_button(lv_event_t *e)
{
    uint8_t code = lv_obj_get_event_code((lv_obj_t *)e);
    if (code == EV_PRESSED) {
        scicalc_pill_paint(1);
    } else if (code == EV_PRESS_LOST || code == EV_RELEASED) {
        scicalc_pill_paint(0);
    } else if (code == EV_CLICKED) {
        scicalc_pill_paint(0);
        g_page = g_page == 0 ? 1 : 0;
        result_fade_stop();
        render();
    }
}

static void on_result_del(lv_event_t *e)
{
    (void)e;
    result_fade_stop();
    do_del();
    render();
}

static void on_key_event(lv_event_t *e)
{
    int i = (int)(uintptr_t)lv_event_get_user_data(e);
    uint8_t code = lv_obj_get_event_code((lv_obj_t *)e);
    if (code == EV_PRESSED) key_paint(i, 1);
    else if (code == EV_RELEASED || code == EV_PRESS_LOST) {
        key_paint(i, 0);
    } else if (code == EV_CLICKED) {
        key_paint(i, 0);
        on_key(i);
    }
}

static void ui_build(lv_obj_t *parent)
{
    /* Keep the result close to the keypad and use the available screen height. */
    static const uint8_t ly[3] = { 82, 8, RESULT_Y }, lh[3] = { 18, 18, RESULT_H };
    static const uint16_t lx[3] = { 68, 14, 24 }, lw[3] = { 90, 112, RESULT_DEL_X - 24 - 8 };
    int i, k;
    lv_obj_t *root = lv_obj_create(parent, 0);
#ifndef NO_SCROLL_FIX   /* lv_obj_clear_flag belum terverifikasi di fw 3.201.016; kalau app crash saat dibuka, build dgn -DNO_SCROLL_FIX */
    lv_obj_clear_flag(parent, FLAG_SCROLLABLE);   /* jangan scroll walau root lebih besar */
    lv_obj_clear_flag(root, FLAG_SCROLLABLE);
#endif
    lv_obj_set_size(root, SCREEN_W + 2 * OUTSET, SCREEN_H + 2 * OUTSET);
    lv_obj_align(root, LV_ALIGN_TOP_LEFT, -OUTSET, -OUTSET);
    lvx_btn_set_style_bg_color(root, COL_BG);
    lv_obj_set_style_bg_opa(root, 255u, 0);
    lv_obj_set_style_pad_left(root, 0, 0);
    lv_obj_set_style_pad_right(root, 0, 0);
    lv_obj_set_style_pad_top(root, 0, 0);
    lv_obj_set_style_pad_bottom(root, 0, 0);
    g_shown = -1;

    for (i = 0; i < 3; i++) {
        lv_obj_t *l = lv_label_create(root);
        lv_obj_set_size(l, lw[i], lh[i]);
        lv_obj_align(l, LV_ALIGN_TOP_LEFT, OUTSET + lx[i],
                     OUTSET + (i == 3 ? 86 : i == 0 ? 86 : ly[i]));
        lv_label_set_long_mode(l, 5);  /* LONG_CLIP: keep readouts on one line */
        if (i > 1) lv_obj_set_style_text_align(l, 3, 0);   /* rata kanan; status & ekspresi rata kiri */
        if (i == 2) lvx_obj_set_style_text(l, (lv_style_t *)STYLE_ADDR(BIGSTYLE), 255, 0);
        g_lbl[i] = l;
    }
    for (i = 0; i < 3; i++) {
        g_page_dots[i] = lvx_btn_create(root);
        lv_obj_set_size(g_page_dots[i], 8, 8);
        lv_obj_align(g_page_dots[i], LV_ALIGN_TOP_LEFT,
                     OUTSET + 290 + i * 12, OUTSET + 91);
        lv_obj_set_style_bg_opa(g_page_dots[i], 255u, 0);
        lvx_btn_set_style_bg_color(g_page_dots[i], i == g_page ? COL_HOME : COL_LINE);
        lv_obj_add_flag(g_page_dots[i], FLAG_CLICKABLE);
        lv_obj_add_event_cb(g_page_dots[i], on_page_dot, EV_CLICKED, (void *)(uintptr_t)i);
    }
    lv_obj_t *divider = lvx_btn_create(root);
    lv_obj_set_size(divider, SCREEN_W - 28, 1);
    lv_obj_align(divider, LV_ALIGN_TOP_LEFT, OUTSET + 14, OUTSET + 82);
    lvx_btn_set_style_bg_color(divider, COL_LINE);

    g_deg_pill = lv_obj_create(root, 0);
    lv_obj_set_size(g_deg_pill, 72, 18);
    lv_obj_align(g_deg_pill, LV_ALIGN_TOP_LEFT, OUTSET + 14, OUTSET + 86);
    lv_obj_set_style_bg_color(g_deg_pill, COL_PILL, 0);
    lv_obj_set_style_bg_opa(g_deg_pill, 255u, 0);
    g_deg_pill_inner = lv_obj_create(root, 0);
    lv_obj_set_size(g_deg_pill_inner, 70, 16);
    lv_obj_align(g_deg_pill_inner, LV_ALIGN_TOP_LEFT, OUTSET + 15, OUTSET + 87);
    lv_obj_set_style_bg_color(g_deg_pill_inner, COL_BG, 0);
    lv_obj_set_style_bg_opa(g_deg_pill_inner, 255u, 0);
    lv_obj_clear_flag(g_deg_pill_inner, FLAG_CLICKABLE);
    g_deg_label = lv_label_create(root);
    lv_obj_set_size(g_deg_label, 72, 18);
    lv_obj_align(g_deg_label, LV_ALIGN_TOP_LEFT, OUTSET + 14, OUTSET + 86);
    lv_obj_set_style_text_align(g_deg_label, 2, 0);
    lv_label_set_text(g_deg_label, "SciCalc");
    lv_obj_add_flag(g_deg_pill, FLAG_CLICKABLE);
    lv_obj_add_event_cb(g_deg_pill, on_scicalc_button, EV_PRESSED, 0);
    lv_obj_add_event_cb(g_deg_pill, on_scicalc_button, EV_PRESS_LOST, 0);
    lv_obj_add_event_cb(g_deg_pill, on_scicalc_button, EV_RELEASED, 0);
    lv_obj_add_event_cb(g_deg_pill, on_scicalc_button, EV_CLICKED, 0);

    lv_obj_t *home_bar = lvx_btn_create(root);
    lv_obj_set_size(home_bar, 72, 4);
    lv_obj_align(home_bar, LV_ALIGN_TOP_LEFT, OUTSET + (SCREEN_W - 72) / 2, OUTSET + 466);
    lvx_btn_set_style_bg_color(home_bar, COL_HOME);

    for (k = 0; k < NKEYS; k++) {
        i = k;
        lv_obj_t *btn = lvx_btn_create(root);
        lv_obj_set_size(btn, BTN_W, BTN_H);
        lv_obj_align(btn, LV_ALIGN_TOP_LEFT, OUTSET + GRID_X + (i % 4) * (BTN_W + BTN_GAP),
                     OUTSET + GRID_Y + (i / 4) * (BTN_H + BTN_GAP));
        lv_obj_add_event_cb(btn, on_key_event, EV_PRESSED, (void *)(uintptr_t)i);
        lv_obj_add_event_cb(btn, on_key_event, EV_PRESS_LOST, (void *)(uintptr_t)i);
        lv_obj_add_event_cb(btn, on_key_event, EV_RELEASED, (void *)(uintptr_t)i);
        lv_obj_add_event_cb(btn, on_key_event, EV_CLICKED, (void *)(uintptr_t)i);
#ifdef KEYSTYLE
        lvx_obj_set_style_text(btn, (lv_style_t *)STYLE_ADDR(KEYSTYLE), 255, 0);
#endif
        g_btn[i] = btn;
    }
    g_result_del = lvx_btn_create(root);
    lv_obj_set_size(g_result_del, RESULT_DEL_W, RESULT_DEL_H);
    lv_obj_align(g_result_del, LV_ALIGN_TOP_LEFT,
                 OUTSET + RESULT_DEL_X, OUTSET + RESULT_DEL_Y);
    lvx_btn_set_style_bg_color(g_result_del, COL_TOP);
    {
        lv_obj_t *icon = lv_label_create(g_result_del);
        lv_obj_set_size(icon, RESULT_DEL_W, RESULT_DEL_H);
        lv_obj_align(icon, LV_ALIGN_CENTER, 0, 0);
        lv_label_set_text(icon, "←");
        lv_obj_set_style_text_align(icon, 2, 0);
        lvx_obj_set_style_text(icon, (lv_style_t *)STYLE_ADDR(3), 255, 0);
    }
    lv_obj_add_event_cb(g_result_del, on_result_del, EV_CLICKED, 0);
    render();
}

/* ---- registrasi app (sama seperti Notes) ---- */
static char *sci_get_name(void) { return "SciCalc"; }

static int sci_on_signal(void *page, lv_obj_t *root, void *data)
{
    (void)page; (void)root; (void)data;
    return 0;
}

static int sci_on_create(void *page, lv_obj_t *root, void *data)
{
    (void)page; (void)data;
    ui_build(root);
    return 0;
}

static int sci_on_destroy(void *page, lv_obj_t *root, void *data)
{
    int i;
    (void)page; (void)root; (void)data;
    result_fade_stop();
    g_shown = -1;
    for (i = 0; i < 3; i++) g_lbl[i] = 0;
    g_deg_label = 0;
    g_result_del = 0;
    for (i = 0; i < 3; i++) g_page_dots[i] = 0;
    for (i = 0; i < NKEYS; i++) g_btn[i] = 0;
    return 0;
}

static char APP_ICON[] = "/data/calc_logo_112.png";

static miwear_app_t g_sci_app = {
    .proto_app = 0, .field_4 = 0,
    .name = APP_NAME, .icon = APP_ICON,
    .app_id = SCI_APP_ID, .flags = 0,
    .field_14 = 0, .field_18 = 0,
    .app_get_name = sci_get_name,
    .on_uninstall = 0,
    .field_24 = 0, .field_28 = 0, .field_2C = 0,
    .field_30 = 0, .field_34 = 0,
    .on_signal = 0, .field_3C = 0,
};

static miwear_page_t g_sci_page = {
    .parent_descriptor = 0,
    .page_name = PAGE_NAME,
    .page_id = SCI_PAGE_ID,
    .app_id = SCI_APP_ID,
    .flags = 0,
    .scheduler_deadline = 0, .scheduler_priority = 0,
    .async_destroy_state = 0, .lifecycle_state = 0,
    .layer = 1, .page_kind = 0,
    .activity_context = 0, .root_object = 0,
    .on_signal = sci_on_signal,
    .runtime_default_56 = 0,
    .registry_prev = 0, .registry_next = 0, .runtime_parent = 0,
    .on_create = sci_on_create,
    .on_resume = 0, .on_newdata = 0, .on_start = 0,
    .on_pause = 0, .on_stop = 0,
    .on_destroy = sci_on_destroy,
    .on_back = 0, .on_keyevent = 0, .get_scroll_obj = 0,
};

static void register_app(void)
{
    if (app_lookup(SCI_APP_ID) != 0) return;
    miwear_page_t *pages[] = { &g_sci_page };
    g_packagemanager_api->install(&g_sci_app, pages, 1);
    app_launcher_add(SCI_APP_ID);
}

/* Hapus watchface installer (watchface yang sedang aktif) lalu kembali ke
 * watchface lain, ~5 dtk setelah modul dimuat. Sama seperti app Calculator
 * asli (delete + reset), hanya ditunda supaya countdown di Lua sempat tampil. */
__attribute__((used)) static void *remove_timer_id;

static void remove_callback(lv_timer_t *timer)
{
    (void)timer;
    lv_timer_delete(remove_timer_id);
    remove_timer_id = 0;
    char *curr_face = g_watchface_config && g_watchface_config->current_face
                    ? g_watchface_config->current_face->id
                    : "";
    watchface_manager_delete_watchface(curr_face);
    watchface_manager_reset_watchface(NULL);
}

static void timer_callback(lv_timer_t *timer)
{
    (void)timer;
    lv_timer_delete(post_timer_id);
    post_timer_id = 0;
    register_app();
    remove_timer_id = lv_timer_create(remove_callback, REMOVE_MS, 0);
}

__attribute__((constructor)) int module_initialize(void)
{
    post_timer_id = lv_timer_create(timer_callback, 500, 0);
    return 0;
}

__attribute__((destructor, used)) static void module_uninitialize(void)
{
}

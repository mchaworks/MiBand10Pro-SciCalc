/* sci_engine.h -- kalkulator ilmiah: aritmetika desimal 40 digit.
 * Freestanding: tanpa libc, tanpa float/double, tanpa int 64-bit.
 * Nilai = (-1)^s * 0.m0 m1 ... m9 * 10000^e   (m[i] basis 10000, m0 != 0). */
#ifndef SCI_ENGINE_H
#define SCI_ENGINE_H
#include <stdint.h>

#define NL      10
#define EXP_MAX 25               /* 10000^25 = 1e100 */
#define SU      static __attribute__((unused))

typedef struct { int32_t s; int32_t e; uint16_t m[NL]; } dec;

enum { ERR_NONE = 0, ERR_MATH = 1, ERR_SYNTAX = 2, ERR_OVER = 3, ERR_DEEP = 4 };
static int g_err;

static const dec K_PI = {0, 1, {3,1415,9265,3589,7932,3846,2643,3832,7950,2884}};
static const dec K_PIO2 = {0, 1, {1,5707,9632,6794,8966,1923,1321,6916,3975,1442}};
static const dec K_INVPIO2 = {0, 0, {6366,1977,2367,5813,4307,5535,534,9005,7448,1378}};
static const dec K_LN10 = {0, 1, {2,3025,8509,2994,456,8401,7991,4546,8436,4208}};
static const dec K_INVLN10 = {0, 0, {4342,9448,1903,2518,2765,1128,9189,1660,5082,2944}};
static const dec K_E = {0, 1, {2,7182,8182,8459,452,3536,287,4713,5266,2498}};

/* ---------------- dasar ---------------- */
SU void d_clr(dec *a) { int i; a->s = 0; a->e = 0; for (i = 0; i < NL; i++) a->m[i] = 0; }
SU int  d_iszero(const dec *a) { return a->m[0] == 0; }
SU void d_cp(dec *r, const dec *a) { int i; r->s = a->s; r->e = a->e; for (i = 0; i < NL; i++) r->m[i] = a->m[i]; }
SU void d_neg(dec *r, const dec *a) { d_cp(r, a); if (r->m[0]) r->s ^= 1; }
SU void d_abs(dec *r, const dec *a) { d_cp(r, a); r->s = 0; }

/* w[0..n-1] limb (0..9999), nilai 0.w0w1.. * 10000^e */
static void d_from_wide(dec *r, int s, int e, const uint32_t *w, int n)
{
    int k0 = 0, i;
    while (k0 < n && w[k0] == 0) k0++;
    if (k0 == n) { d_clr(r); return; }
    for (i = 0; i < NL; i++) r->m[i] = (k0 + i < n) ? (uint16_t)w[k0 + i] : 0;
    r->s = s; r->e = e - k0;
    if (r->e > EXP_MAX) { g_err = ERR_OVER; r->e = EXP_MAX; }
    else if (r->e < -EXP_MAX) d_clr(r);
}

SU void d_from_u32(dec *r, uint32_t n)
{
    uint32_t w[3];
    w[0] = n / 100000000u; w[1] = (n / 10000u) % 10000u; w[2] = n % 10000u;
    d_from_wide(r, 0, 3, w, 3);
}
SU void d_from_i32(dec *r, int32_t n)
{
    if (n < 0) { d_from_u32(r, (uint32_t)(-(n + 1)) + 1u); if (r->m[0]) r->s = 1; }
    else d_from_u32(r, (uint32_t)n);
}

/* bandingkan nilai: -1,0,1 */
static int d_cmp(const dec *a, const dec *b)
{
    int i, sg;
    if (a->m[0] == 0 && b->m[0] == 0) return 0;
    if (a->m[0] == 0) return b->s ? 1 : -1;
    if (b->m[0] == 0) return a->s ? -1 : 1;
    if (a->s != b->s) return a->s ? -1 : 1;
    sg = a->s ? -1 : 1;
    if (a->e != b->e) return (a->e > b->e) ? sg : -sg;
    for (i = 0; i < NL; i++)
        if (a->m[i] != b->m[i]) return (a->m[i] > b->m[i]) ? sg : -sg;
    return 0;
}

#define WN (NL + 3)
static void d_addsub(dec *r, const dec *a, const dec *b, int sub)
{
    uint32_t X[WN], Y[WN], R[WN];
    int bs = b->s ^ (sub ? 1 : 0), E, sh, i, c;
    int32_t v;
    if (b->m[0] == 0) { d_cp(r, a); return; }
    if (a->m[0] == 0) { d_cp(r, b); r->s = bs; return; }
    E = (a->e > b->e) ? a->e : b->e;
    for (i = 0; i < WN; i++) { X[i] = 0; Y[i] = 0; R[i] = 0; }
    sh = E - a->e;
    for (i = 0; i < NL; i++) if (1 + i + sh < WN) X[1 + i + sh] = a->m[i];
    sh = E - b->e;
    for (i = 0; i < NL; i++) if (1 + i + sh < WN) Y[1 + i + sh] = b->m[i];
    if (a->s == bs) {
        c = 0;
        for (i = WN - 1; i >= 0; i--) {
            v = (int32_t)(X[i] + Y[i]) + c;
            R[i] = (uint32_t)(v % 10000); c = v / 10000;
        }
        d_from_wide(r, a->s, E + 1, R, WN);
    } else {
        int cm = 0, sg;
        for (i = 0; i < WN; i++) if (X[i] != Y[i]) { cm = (X[i] > Y[i]) ? 1 : -1; break; }
        if (cm == 0) { d_clr(r); return; }
        if (cm < 0) { for (i = 0; i < WN; i++) { uint32_t q = X[i]; X[i] = Y[i]; Y[i] = q; } sg = bs; }
        else sg = a->s;
        c = 0;
        for (i = WN - 1; i >= 0; i--) {
            v = (int32_t)X[i] - (int32_t)Y[i] - c;
            if (v < 0) { v += 10000; c = 1; } else c = 0;
            R[i] = (uint32_t)v;
        }
        d_from_wide(r, sg, E + 1, R, WN);
    }
}
SU void d_add(dec *r, const dec *a, const dec *b) { d_addsub(r, a, b, 0); }
SU void d_sub(dec *r, const dec *a, const dec *b) { d_addsub(r, a, b, 1); }

static void d_mul(dec *r, const dec *a, const dec *b)
{
    uint32_t t[2 * NL];
    int i, j;
    uint32_t c;
    if (a->m[0] == 0 || b->m[0] == 0) { d_clr(r); return; }
    for (i = 0; i < 2 * NL; i++) t[i] = 0;
    for (i = 0; i < NL; i++)
        for (j = 0; j < NL; j++)
            t[i + j + 1] += (uint32_t)a->m[i] * (uint32_t)b->m[j];
    for (i = 2 * NL - 1; i >= 1; i--) { c = t[i] / 10000u; t[i] %= 10000u; t[i - 1] += c; }
    d_from_wide(r, a->s ^ b->s, a->e + b->e, t, 2 * NL);
}

/* bagi dengan bilangan kecil n (1..65535) */
static void d_div_small(dec *r, const dec *a, uint32_t n)
{
    uint32_t q[NL + 1], rem = 0, cur;
    int i;
    if (a->m[0] == 0) { d_clr(r); return; }
    for (i = 0; i <= NL; i++) {
        cur = rem * 10000u + ((i < NL) ? a->m[i] : 0u);
        q[i] = cur / n; rem = cur % n;
    }
    d_from_wide(r, a->s, a->e, q, NL + 1);
}

/* pembulatan ke 8 limb (>= 29 digit): membuang derau digit ujung */
static void d_rnd(dec *a)
{
    int i;
    if (a->m[0] == 0) return;
    if (a->m[8] >= 5000) {
        i = 7;
        for (;;) {
            if (a->m[i] == 9999) { a->m[i] = 0; if (i == 0) { a->m[0] = 1; a->e++; break; } i--; }
            else { a->m[i]++; break; }
        }
    }
    a->m[8] = 0; a->m[9] = 0;
    if (a->e > EXP_MAX) { g_err = ERR_OVER; a->e = EXP_MAX; }
}

static void d_recip(dec *r, const dec *a)
{
    dec x, t, p, two;
    uint32_t v, gi;
    int k, sg = a->s;
    if (a->m[0] == 0) { g_err = ERR_MATH; d_clr(r); return; }
    v = (uint32_t)a->m[0] * 10000u + a->m[1];
    gi = 1000000000u / (v / 1000u + 1u);
    d_from_u32(&x, gi);
    x.e += -1 - a->e;
    d_abs(&p, a);
    d_from_u32(&two, 2);
    for (k = 0; k < 6; k++) {
        d_mul(&t, &p, &x);
        d_sub(&t, &two, &t);
        d_mul(&x, &x, &t);
    }
    x.s = sg;
    d_cp(r, &x);
    if (x.e > EXP_MAX) g_err = ERR_OVER;
}
static void d_div(dec *r, const dec *a, const dec *b)
{
    dec q;
    if (b->m[0] == 0) { g_err = ERR_MATH; d_clr(r); return; }
    d_recip(&q, b);
    d_mul(r, a, &q);
}

static uint32_t isqrt32(uint32_t n)
{
    uint32_t x = 0, bit = 1u << 30;
    while (bit > n) bit >>= 2;
    while (bit) {
        if (n >= x + bit) { n -= x + bit; x = (x >> 1) + bit; } else x >>= 1;
        bit >>= 2;
    }
    return x;
}
static void d_sqrt(dec *r, const dec *a)
{
    dec x, t, p;
    uint32_t v, s0;
    int k;
    if (a->m[0] == 0) { d_clr(r); return; }
    if (a->s) { g_err = ERR_MATH; d_clr(r); return; }
    v = (uint32_t)a->m[0] * 10000u + a->m[1];
    s0 = isqrt32(v);
    d_from_u32(&x, s0);
    if ((a->e & 1) == 0) x.e += a->e / 2 - 1;
    else { d_div_small(&x, &x, 100); x.e += (a->e - 1) / 2; }
    d_cp(&p, a);
    for (k = 0; k < 6; k++) {
        d_div(&t, &p, &x);
        d_add(&x, &x, &t);
        d_div_small(&x, &x, 2);
    }
    d_cp(r, &x);
}

/* integer murni? -> n (|n| < 2e9). */
static int d_int_val(const dec *a, int32_t *n)
{
    int i;
    uint32_t v = 0;
    if (a->m[0] == 0) { *n = 0; return 1; }
    if (a->e < 1 || a->e > 3) return 0;
    for (i = a->e; i < NL; i++) if (a->m[i]) return 0;
    if (a->e == 3 && a->m[0] > 20) return 0;
    for (i = 0; i < a->e; i++) v = v * 10000u + a->m[i];
    *n = a->s ? -(int32_t)v : (int32_t)v;
    return 1;
}
/* bulatkan ke integer terdekat; 0 jika di luar jangkauan */
static int d_round_i32(const dec *a, int32_t *n)
{
    int i;
    uint32_t v = 0;
    int up = 0;
    if (a->m[0] == 0) { *n = 0; return 1; }
    if (a->e < 0) { *n = 0; return 1; }
    if (a->e == 0) { up = a->m[0] >= 5000; *n = up ? (a->s ? -1 : 1) : 0; return 1; }
    if (a->e > 3) return 0;
    if (a->e == 3 && a->m[0] > 20) return 0;
    for (i = 0; i < a->e; i++) v = v * 10000u + a->m[i];
    up = a->m[a->e] >= 5000;
    v += (uint32_t)up;
    *n = a->s ? -(int32_t)v : (int32_t)v;
    return 1;
}

static int negligible(const dec *term, const dec *sum)
{
    return term->m[0] == 0 || term->e < sum->e - (NL + 1);
}

/* ---------------- exp / ln ---------------- */
static void d_exp(dec *r, const dec *x)
{
    dec q, rr, sum, term, one, t;
    int32_t n;
    int k, qn, rn;
    if (x->m[0] == 0) { d_from_u32(r, 1); return; }
    if (x->e > 1 || (x->e == 1 && x->m[0] >= 231)) {
        if (x->s) { d_clr(r); return; }
        g_err = ERR_OVER; d_clr(r); return;
    }
    d_mul(&q, x, &K_INVLN10);
    if (!d_round_i32(&q, &n)) { g_err = ERR_OVER; d_clr(r); return; }
    d_from_i32(&t, n);
    d_mul(&t, &t, &K_LN10);
    d_sub(&rr, x, &t);
    d_div_small(&rr, &rr, 1024);
    d_from_u32(&one, 1);
    d_cp(&sum, &one); d_cp(&term, &one);
    for (k = 1; k < 40; k++) {
        d_mul(&term, &term, &rr);
        d_div_small(&term, &term, (uint32_t)k);
        d_add(&sum, &sum, &term);
        if (negligible(&term, &sum)) break;
    }
    for (k = 0; k < 10; k++) d_mul(&sum, &sum, &sum);
    qn = (n >= 0) ? n / 4 : -((-n + 3) / 4);
    rn = n - 4 * qn;
    if (rn) { d_from_u32(&t, rn == 1 ? 10u : (rn == 2 ? 100u : 1000u)); d_mul(&sum, &sum, &t); }
    sum.e += qn;
    if (sum.e > EXP_MAX) { g_err = ERR_OVER; d_clr(r); return; }
    if (sum.e < -EXP_MAX) { d_clr(r); return; }
    d_cp(r, &sum);
}

static void d_ln(dec *r, const dec *x)
{
    dec t, y, z, term, sum, one, a, b, res, kk;
    int K, nd, k, i;
    if (x->m[0] == 0 || x->s) { g_err = ERR_MATH; d_clr(r); return; }
    d_cp(&t, x);
    K = 4 * (x->e - 1);
    t.e = 1;
    nd = t.m[0] >= 1000 ? 4 : (t.m[0] >= 100 ? 3 : (t.m[0] >= 10 ? 2 : 1));
    if (nd > 1) { d_div_small(&t, &t, nd == 2 ? 10u : (nd == 3 ? 100u : 1000u)); K += nd - 1; }
    d_from_u32(&one, 1);
    for (i = 0; i < 4; i++) d_sqrt(&t, &t);
    d_sub(&a, &t, &one); d_add(&b, &t, &one);
    d_div(&y, &a, &b);
    d_mul(&z, &y, &y);
    d_cp(&term, &y); d_cp(&sum, &y);
    for (k = 1; k < 80; k++) {
        if (term.m[0] == 0) break;
        d_mul(&term, &term, &z);
        d_div_small(&a, &term, (uint32_t)(2 * k + 1));
        d_add(&sum, &sum, &a);
        if (negligible(&a, &sum)) break;
    }
    d_from_u32(&kk, 32);
    d_mul(&res, &sum, &kk);
    d_from_i32(&kk, K);
    d_mul(&kk, &kk, &K_LN10);
    d_add(r, &res, &kk);
}
static void d_log10(dec *r, const dec *x)
{
    dec t, y, kk;
    int K, nd;
    if (x->m[0] == 0 || x->s) { g_err = ERR_MATH; d_clr(r); return; }
    d_cp(&t, x);
    K = 4 * (x->e - 1);
    t.e = 1;
    nd = t.m[0] >= 1000 ? 4 : (t.m[0] >= 100 ? 3 : (t.m[0] >= 10 ? 2 : 1));
    if (nd > 1) { d_div_small(&t, &t, nd == 2 ? 10u : (nd == 3 ? 100u : 1000u)); K += nd - 1; }
    d_ln(&y, &t);
    d_mul(&y, &y, &K_INVLN10);
    d_from_i32(&kk, K);
    d_add(r, &kk, &y);
}

/* x^y */
static void d_pow(dec *r, const dec *x, const dec *y)
{
    dec base, acc, t;
    int32_t n;
    uint32_t u;
    if (y->m[0] == 0) {
        if (x->m[0] == 0) { g_err = ERR_MATH; d_clr(r); return; }
        d_from_u32(r, 1); return;
    }
    if (x->m[0] == 0) {
        if (y->s) { g_err = ERR_MATH; d_clr(r); } else d_clr(r);
        return;
    }
    if (d_int_val(y, &n)) {
        d_cp(&base, x);
        d_from_u32(&acc, 1);
        u = (uint32_t)(n < 0 ? -n : n);
        while (u && !g_err) {
            if (u & 1u) d_mul(&acc, &acc, &base);
            u >>= 1;
            if (u) d_mul(&base, &base, &base);
        }
        if (n < 0) { d_recip(&t, &acc); d_cp(r, &t); } else d_cp(r, &acc);
        return;
    }
    if (x->s) { g_err = ERR_MATH; d_clr(r); return; }
    d_ln(&t, x);
    d_mul(&t, &t, y);
    d_exp(r, &t);
}

/* ---------------- trigonometri (radian) ---------------- */
static void sincos_small(dec *s, dec *c, const dec *x)   /* |x| <= ~0.8 */
{
    dec z, term, one;
    int k;
    d_mul(&z, x, x);
    d_cp(&term, x); d_cp(s, x);
    for (k = 1; k < 40; k++) {
        if (term.m[0] == 0) break;
        d_mul(&term, &term, &z);
        d_div_small(&term, &term, (uint32_t)((2 * k) * (2 * k + 1)));
        d_neg(&term, &term);
        d_add(s, s, &term);
        if (negligible(&term, s)) break;
    }
    d_from_u32(&one, 1);
    d_cp(&term, &one); d_cp(c, &one);
    for (k = 1; k < 40; k++) {
        d_mul(&term, &term, &z);
        d_div_small(&term, &term, (uint32_t)((2 * k - 1) * (2 * k)));
        d_neg(&term, &term);
        d_add(c, c, &term);
        if (negligible(&term, c)) break;
    }
}
/* sin dan cos dari x radian (|x| < 1e9) */
static void d_sincos(dec *s, dec *c, const dec *x)
{
    dec q, t, rr, ss, cc;
    int32_t n;
    int quad;
    if (x->m[0] == 0) { d_clr(s); d_from_u32(c, 1); return; }
    if (x->e > 3 || (x->e == 3 && x->m[0] > 20)) { g_err = ERR_MATH; d_clr(s); d_clr(c); return; }
    d_mul(&q, x, &K_INVPIO2);
    if (!d_round_i32(&q, &n)) { g_err = ERR_MATH; d_clr(s); d_clr(c); return; }
    d_from_i32(&t, n);
    d_mul(&t, &t, &K_PIO2);
    d_sub(&rr, x, &t);
    sincos_small(&ss, &cc, &rr);
    quad = (int)(((n % 4) + 4) % 4);
    if (quad == 0) { d_cp(s, &ss); d_cp(c, &cc); }
    else if (quad == 1) { d_cp(s, &cc); d_neg(c, &ss); }
    else if (quad == 2) { d_neg(s, &ss); d_neg(c, &cc); }
    else { d_neg(s, &cc); d_cp(c, &ss); }
}

/* atan(x) radian */
static void d_atan(dec *r, const dec *x)
{
    dec ax, one, t, z, term, sum, a;
    int sg = x->s, inv = 0, k, i;
    if (x->m[0] == 0) { d_clr(r); return; }
    d_abs(&ax, x);
    d_from_u32(&one, 1);
    if (d_cmp(&ax, &one) > 0) { d_recip(&t, &ax); d_cp(&ax, &t); inv = 1; }
    for (i = 0; i < 3; i++) {
        d_mul(&t, &ax, &ax);
        d_add(&t, &t, &one);
        d_sqrt(&t, &t);
        d_add(&t, &t, &one);
        d_div(&ax, &ax, &t);
    }
    d_mul(&z, &ax, &ax);
    d_cp(&term, &ax); d_cp(&sum, &ax);
    for (k = 1; k < 80; k++) {
        d_mul(&term, &term, &z);
        d_div_small(&a, &term, (uint32_t)(2 * k + 1));
        if (k & 1) d_sub(&sum, &sum, &a); else d_add(&sum, &sum, &a);
        if (negligible(&a, &sum)) break;
    }
    d_from_u32(&t, 8);
    d_mul(&sum, &sum, &t);
    if (inv) d_sub(&sum, &K_PIO2, &sum);
    sum.s = (sum.m[0] != 0) ? sg : 0;
    d_cp(r, &sum);
}
static void d_asin(dec *r, const dec *x)
{
    dec ax, one, t, u;
    d_abs(&ax, x);
    d_from_u32(&one, 1);
    if (d_cmp(&ax, &one) > 0) { g_err = ERR_MATH; d_clr(r); return; }
    if (d_cmp(&ax, &one) == 0) { d_cp(r, &K_PIO2); r->s = x->s; return; }
    d_mul(&t, x, x);
    d_sub(&t, &one, &t);
    d_sqrt(&t, &t);
    d_div(&u, x, &t);
    d_atan(r, &u);
}
static void d_acos(dec *r, const dec *x)
{
    dec a;
    d_asin(&a, x);
    if (g_err) { d_clr(r); return; }
    d_sub(r, &K_PIO2, &a);
}

/* ---------------- hiperbolik ---------------- */
static void sinh_series(dec *r, const dec *x)
{
    dec z, term, sum;
    int k;
    d_mul(&z, x, x);
    d_cp(&term, x); d_cp(&sum, x);
    for (k = 1; k < 60; k++) {
        d_mul(&term, &term, &z);
        d_div_small(&term, &term, (uint32_t)((2 * k) * (2 * k + 1)));
        d_add(&sum, &sum, &term);
        if (negligible(&term, &sum)) break;
    }
    d_cp(r, &sum);
}
static void d_sinh(dec *r, const dec *x)
{
    dec ax, E, iE, one;
    if (x->m[0] == 0) { d_clr(r); return; }
    d_abs(&ax, x);
    d_from_u32(&one, 1);
    if (d_cmp(&ax, &one) < 0) { sinh_series(r, x); return; }
    d_exp(&E, &ax);
    if (g_err) { d_clr(r); return; }
    d_recip(&iE, &E);
    d_sub(&E, &E, &iE);
    d_div_small(&E, &E, 2);
    E.s = x->s;
    d_cp(r, &E);
}
static void d_cosh(dec *r, const dec *x)
{
    dec ax, E, iE;
    d_abs(&ax, x);
    d_exp(&E, &ax);
    if (g_err) { d_clr(r); return; }
    d_recip(&iE, &E);
    d_add(&E, &E, &iE);
    d_div_small(r, &E, 2);
}
static void d_tanh(dec *r, const dec *x)
{
    dec ax, E, a, b, one;
    if (x->m[0] == 0) { d_clr(r); return; }
    d_abs(&ax, x);
    d_from_u32(&one, 1);
    if (ax.e > 1 || (ax.e == 1 && ax.m[0] >= 60)) { d_cp(r, &one); r->s = x->s; return; }
    if (d_cmp(&ax, &one) < 0) {
        sinh_series(&a, x);
        d_mul(&b, &a, &a); d_add(&b, &b, &one); d_sqrt(&b, &b);
        d_div(r, &a, &b);
        return;
    }
    d_exp(&E, &ax);
    d_mul(&E, &E, &E);
    d_sub(&a, &E, &one); d_add(&b, &E, &one);
    d_div(&a, &a, &b);
    a.s = x->s;
    d_cp(r, &a);
}
static void d_asinh(dec *r, const dec *x)
{
    dec ax, t, one, c, lim;
    if (x->m[0] == 0) { d_clr(r); return; }
    d_abs(&ax, x);
    d_from_u32(&lim, 1); d_div_small(&lim, &lim, 100);          /* 0.01 */
    if (d_cmp(&ax, &lim) < 0) {   /* x - x^3/6 + 3x^5/40 - 15x^7/336 */
        dec x2, x3, x5, x7, u;
        d_mul(&x2, x, x); d_mul(&x3, &x2, x); d_mul(&x5, &x3, &x2); d_mul(&x7, &x5, &x2);
        d_div_small(&u, &x3, 6); d_sub(&c, x, &u);
        d_from_u32(&u, 3); d_mul(&u, &u, &x5); d_div_small(&u, &u, 40); d_add(&c, &c, &u);
        d_from_u32(&u, 15); d_mul(&u, &u, &x7); d_div_small(&u, &u, 336); d_sub(&c, &c, &u);
        d_cp(r, &c);
        return;
    }
    d_from_u32(&one, 1);
    d_mul(&t, &ax, &ax); d_add(&t, &t, &one); d_sqrt(&t, &t);
    d_add(&t, &t, &ax);
    d_ln(&c, &t);
    c.s = x->s;
    d_cp(r, &c);
}
static void d_acosh(dec *r, const dec *x)
{
    dec one, t, c;
    d_from_u32(&one, 1);
    if (d_cmp(x, &one) < 0) { g_err = ERR_MATH; d_clr(r); return; }
    d_mul(&t, x, x); d_sub(&t, &t, &one); d_sqrt(&t, &t);
    d_add(&t, &t, x);
    d_ln(&c, &t);
    d_cp(r, &c);
}
static void d_atanh(dec *r, const dec *x)
{
    dec ax, one, a, b, z, term, sum, t;
    int k;
    d_abs(&ax, x);
    d_from_u32(&one, 1);
    if (d_cmp(&ax, &one) >= 0) { g_err = ERR_MATH; d_clr(r); return; }
    if (x->m[0] == 0) { d_clr(r); return; }
    d_from_u32(&t, 1); d_div_small(&t, &t, 2);       /* 0.5 */
    if (d_cmp(&ax, &t) < 0) {
        d_mul(&z, x, x);
        d_cp(&term, x); d_cp(&sum, x);
        for (k = 1; k < 200; k++) {
            d_mul(&term, &term, &z);
            d_div_small(&a, &term, (uint32_t)(2 * k + 1));
            d_add(&sum, &sum, &a);
            if (negligible(&a, &sum)) break;
        }
        d_cp(r, &sum);
        return;
    }
    d_add(&a, &one, x); d_sub(&b, &one, x);
    d_div(&a, &a, &b);
    d_ln(&a, &a);
    d_div_small(r, &a, 2);
}

/* n! */
static void d_fact(dec *r, const dec *x)
{
    int32_t n, i;
    dec acc, t;
    if (!d_int_val(x, &n) || n < 0 || n > 69) { g_err = ERR_MATH; d_clr(r); return; }
    d_from_u32(&acc, 1);
    for (i = 2; i <= n; i++) { d_from_u32(&t, (uint32_t)i); d_mul(&acc, &acc, &t); }
    d_cp(r, &acc);
}
static void d_cbrt(dec *r, const dec *x)
{
    dec ax, t;
    if (x->m[0] == 0) { d_clr(r); return; }
    d_abs(&ax, x);
    d_ln(&t, &ax);
    d_div_small(&t, &t, 3);
    d_exp(&t, &t);
    t.s = x->s;
    d_cp(r, &t);
}

/* ---------------- parsing & format ---------------- */
static void d_from_digits(dec *r, const char *dg, int nd, int X, int neg)
{
    uint32_t w[NL];
    int i = 0, e, pad, k, j, idx;
    while (i < nd && dg[i] == '0') { i++; X--; }
    if (i == nd) { d_clr(r); return; }
    dg += i; nd -= i;
    if (nd > 4 * NL) nd = 4 * NL;
    e = (X >= 0) ? (X + 3) / 4 : -((-X) / 4);
    pad = 4 * e - X;
    for (k = 0; k < NL; k++) {
        uint32_t v = 0;
        for (j = 0; j < 4; j++) {
            idx = 4 * k + j - pad;
            v = v * 10u + ((idx >= 0 && idx < nd) ? (uint32_t)(dg[idx] - '0') : 0u);
        }
        w[k] = v;
    }
    d_from_wide(r, neg, e, w, NL);
}

/* maxsd <= 30 digit signifikan */
static void d_fmt(const dec *a, char *out, int maxsd)
{
    char dg[4 * NL + 1];
    int rd[32];
    int i, j, f, x10, nd, n = 0, rnd;
    if (a->m[0] == 0) { out[0] = '0'; out[1] = 0; return; }
    for (i = 0; i < NL; i++) {
        dg[4 * i] = (char)('0' + a->m[i] / 1000);
        dg[4 * i + 1] = (char)('0' + (a->m[i] / 100) % 10);
        dg[4 * i + 2] = (char)('0' + (a->m[i] / 10) % 10);
        dg[4 * i + 3] = (char)('0' + a->m[i] % 10);
    }
    dg[4 * NL] = 0;
    f = 0; while (dg[f] == '0') f++;
    x10 = 4 * a->e - 1 - f;
    for (j = 0; j < maxsd; j++) rd[j] = (f + j < 4 * NL) ? dg[f + j] - '0' : 0;
    rnd = (f + maxsd < 4 * NL) ? (dg[f + maxsd] >= '5') : 0;
    if (rnd) {
        j = maxsd - 1;
        for (;;) {
            if (rd[j] == 9) { rd[j] = 0; if (j == 0) { rd[0] = 1; x10++; break; } j--; }
            else { rd[j]++; break; }
        }
    }
    nd = maxsd; while (nd > 1 && rd[nd - 1] == 0) nd--;
    if (a->s) out[n++] = '-';
    if (x10 >= -5 && x10 <= maxsd - 1 && x10 <= 11) {
        if (x10 >= 0) {
            for (j = 0; j <= x10; j++) out[n++] = (char)('0' + (j < nd ? rd[j] : 0));
            if (nd > x10 + 1) { out[n++] = '.'; for (j = x10 + 1; j < nd; j++) out[n++] = (char)('0' + rd[j]); }
        } else {
            out[n++] = '0'; out[n++] = '.';
            for (j = 0; j < -x10 - 1; j++) out[n++] = '0';
            for (j = 0; j < nd; j++) out[n++] = (char)('0' + rd[j]);
        }
    } else {
        int ex = x10 < 0 ? -x10 : x10;
        out[n++] = (char)('0' + rd[0]);
        if (nd > 1) { out[n++] = '.'; for (j = 1; j < nd; j++) out[n++] = (char)('0' + rd[j]); }
        out[n++] = 'E'; out[n++] = x10 < 0 ? '-' : '+';
        if (ex >= 100) out[n++] = (char)('0' + ex / 100);
        out[n++] = (char)('0' + (ex / 10) % 10);
        out[n++] = (char)('0' + ex % 10);
    }
    out[n] = 0;
}

/* ---------------- evaluator ekspresi ---------------- */
static const char *g_p;
static int g_deg = 1;
static int g_depth;
static dec g_ans;
#define MAXDEPTH 6

static void ev_expr(dec *r);

static int is_digit(char c) { return c >= '0' && c <= '9'; }
static int is_lower(char c) { return c >= 'a' && c <= 'z'; }
static int starts_primary(char c) { return is_digit(c) || c == '.' || c == '(' || is_lower(c) || c == 'A'; }

static int name_eq(const char *s, int n, const char *k)
{
    int i;
    for (i = 0; i < n; i++) if (k[i] != s[i]) return 0;
    return k[n] == 0;
}
enum { F_NONE = 0, F_SIN, F_COS, F_TAN, F_ASIN, F_ACOS, F_ATAN, F_SINH, F_COSH, F_TANH,
       F_ASINH, F_ACOSH, F_ATANH, F_LN, F_LOG, F_SQRT, F_CBRT, F_ABS, F_EXP };
static int func_id(const char *s, int n)
{
    static const char *const nm[] = {"", "sin", "cos", "tan", "asin", "acos", "atan", "sinh", "cosh", "tanh",
        "asinh", "acosh", "atanh", "ln", "log", "sqrt", "cbrt", "abs", "exp"};
    int i;
    for (i = 1; i <= F_EXP; i++) if (name_eq(s, n, nm[i])) return i;
    return F_NONE;
}

/* sudut -> radian untuk sin/cos/tan; mode derajat direduksi eksak */
static void trig(int f, dec *r, const dec *x)
{
    dec rr, s, c, t, q;
    int32_t n, k;
    if (g_deg) {
        if (x->e > 3 || (x->e == 3 && x->m[0] > 20)) { g_err = ERR_MATH; d_clr(r); return; }
        d_from_u32(&t, 360);
        d_div(&q, x, &t);
        if (!d_round_i32(&q, &n)) { g_err = ERR_MATH; d_clr(r); return; }
        d_from_i32(&q, n); d_mul(&q, &q, &t);
        d_sub(&rr, x, &q);                       /* [-180,180] eksak */
        if (d_int_val(&rr, &k) && (k % 90) == 0) {
            int q4 = (int)(((k / 90) % 4 + 4) % 4);   /* 0,1,2,3 -> 0,90,180,270 */
            int sv = (q4 == 1) ? 1 : (q4 == 3 ? -1 : 0);
            int cv = (q4 == 0) ? 1 : (q4 == 2 ? -1 : 0);
            if (f == F_SIN) d_from_i32(r, sv);
            else if (f == F_COS) d_from_i32(r, cv);
            else { if (cv == 0) { g_err = ERR_MATH; d_clr(r); } else d_clr(r); }
            return;
        }
        d_mul(&rr, &rr, &K_PI);
        d_div_small(&rr, &rr, 180);
    } else {
        d_cp(&rr, x);
    }
    d_sincos(&s, &c, &rr);
    if (g_err) { d_clr(r); return; }
    if (f == F_SIN) d_cp(r, &s);
    else if (f == F_COS) d_cp(r, &c);
    else {
        if (c.m[0] == 0 || c.e < -6) { g_err = ERR_MATH; d_clr(r); return; }   /* |cos| < 1e-24 */
        d_div(r, &s, &c);
    }
    if (r->m[0] && r->e < -6 && !g_deg && (x->e >= 1 || (x->e == 0 && x->m[0] >= 10))) d_clr(r);
    else if (r->m[0] && r->e < -6 && g_deg) d_clr(r);
}
static void to_deg(dec *r)
{
    dec t;
    if (!g_deg || r->m[0] == 0) return;
    d_from_u32(&t, 180);
    d_mul(r, r, &t);
    d_div(r, r, &K_PI);
}

static void apply_func(int f, dec *r, const dec *x)
{
    switch (f) {
    case F_SIN: case F_COS: case F_TAN: trig(f, r, x); break;
    case F_ASIN: d_asin(r, x); to_deg(r); break;
    case F_ACOS: d_acos(r, x); to_deg(r); break;
    case F_ATAN: d_atan(r, x); to_deg(r); break;
    case F_SINH: d_sinh(r, x); break;
    case F_COSH: d_cosh(r, x); break;
    case F_TANH: d_tanh(r, x); break;
    case F_ASINH: d_asinh(r, x); break;
    case F_ACOSH: d_acosh(r, x); break;
    case F_ATANH: d_atanh(r, x); break;
    case F_LN: d_ln(r, x); break;
    case F_LOG: d_log10(r, x); break;
    case F_SQRT: d_sqrt(r, x); break;
    case F_CBRT: d_cbrt(r, x); break;
    case F_ABS: d_abs(r, x); break;
    case F_EXP: d_exp(r, x); break;
    default: g_err = ERR_SYNTAX; break;
    }
    if (!g_err) d_rnd(r);
}

static void ev_number(dec *r)
{
    char dg[64];
    int nd = 0, intd = 0, X, ev = 0, es = 1, seen_dot = 0, any = 0;
    for (;;) {
        char c = *g_p;
        if (is_digit(c)) { if (nd < 60) dg[nd++] = c; if (!seen_dot) intd++; any = 1; g_p++; }
        else if (c == '.' && !seen_dot) { seen_dot = 1; g_p++; }
        else break;
    }
    if (!any) { g_err = ERR_SYNTAX; d_clr(r); return; }
    if (*g_p == 'E') {
        const char *q = g_p + 1;
        int sgn = 1;
        if (*q == '+') q++; else if (*q == '-') { sgn = -1; q++; }
        if (is_digit(*q)) {
            int cnt = 0;
            while (is_digit(*q)) { if (cnt < 4) ev = ev * 10 + (*q - '0'); cnt++; q++; }
            es = sgn; g_p = q;
        } else { g_err = ERR_SYNTAX; d_clr(r); return; }
    }
    if (ev > 999) ev = 999;
    X = intd + es * ev;
    d_from_digits(r, dg, nd, X, 0);
    if (r->m[0] && r->e >= EXP_MAX) g_err = ERR_OVER;
}

static void ev_primary(dec *r)
{
    char c = *g_p;
    if (g_err) { d_clr(r); return; }
    if (is_digit(c) || c == '.') { ev_number(r); return; }
    if (c == '(') {
        if (++g_depth > MAXDEPTH) { g_err = ERR_DEEP; d_clr(r); return; }
        g_p++;
        ev_expr(r);
        if (!g_err) {
            if (*g_p == ')') g_p++;
            else if (*g_p != 0) g_err = ERR_SYNTAX;
        }
        g_depth--;
        return;
    }
    if (c == 'A') {
        if (g_p[1] == 'n' && g_p[2] == 's') { g_p += 3; d_cp(r, &g_ans); return; }
        g_err = ERR_SYNTAX; d_clr(r); return;
    }
    if (is_lower(c)) {
        const char *s = g_p;
        int n = 0, f;
        while (is_lower(g_p[n])) n++;
        g_p += n;
        if (name_eq(s, n, "pi")) { d_cp(r, &K_PI); return; }
        if (name_eq(s, n, "e")) { d_cp(r, &K_E); return; }
        f = func_id(s, n);
        if (f == F_NONE || *g_p != '(') { g_err = ERR_SYNTAX; d_clr(r); return; }
        if (++g_depth > MAXDEPTH) { g_err = ERR_DEEP; d_clr(r); return; }
        g_p++;
        {
            dec x;
            ev_expr(&x);
            if (!g_err) {
                if (*g_p == ')') g_p++;
                else if (*g_p != 0) g_err = ERR_SYNTAX;
            }
            if (!g_err) apply_func(f, r, &x); else d_clr(r);
        }
        g_depth--;
        return;
    }
    g_err = ERR_SYNTAX; d_clr(r);
}
static void ev_postfix(dec *r)
{
    ev_primary(r);
    while (!g_err && (*g_p == '!' || *g_p == '%')) {
        dec t;
        if (*g_p == '!') {
            g_p++;
            d_fact(&t, r);
            if (g_err) return;
            d_rnd(&t); d_cp(r, &t);
        } else {
            g_p++;
            d_div_small(&t, r, 100);
            if (g_err) return;
            d_rnd(&t); d_cp(r, &t);
        }
    }
}
static void ev_unary(dec *r);
static void ev_power(dec *r)
{
    ev_postfix(r);
    if (!g_err && *g_p == '^') {
        dec e, t;
        g_p++;
        ev_unary(&e);
        if (g_err) return;
        d_pow(&t, r, &e);
        if (g_err) return;
        d_rnd(&t); d_cp(r, &t);
    }
}
static void ev_unary(dec *r)
{
    if (g_err) { d_clr(r); return; }
    if (*g_p == '-' || *g_p == '+') {
        int neg = (*g_p == '-');
        g_p++;
        if (++g_depth > MAXDEPTH) { g_err = ERR_DEEP; d_clr(r); return; }
        ev_unary(r);
        g_depth--;
        if (neg && !g_err) d_neg(r, r);
        return;
    }
    ev_power(r);
}
static void ev_term(dec *r)
{
    dec t;
    ev_unary(r);
    while (!g_err) {
        char c = *g_p;
        if (c == '*' || c == '/') {
            g_p++;
            ev_unary(&t);
            if (g_err) return;
            if (c == '*') d_mul(r, r, &t); else d_div(r, r, &t);
            if (g_err) return;
            d_rnd(r);
        } else if (starts_primary(c)) {
            ev_power(&t);
            if (g_err) return;
            d_mul(r, r, &t);
            d_rnd(r);
        } else break;
    }
}
static void ev_expr(dec *r)
{
    dec t;
    ev_term(r);
    while (!g_err) {
        char c = *g_p;
        if (c == '+' || c == '-') {
            g_p++;
            ev_term(&t);
            if (g_err) return;
            d_addsub(r, r, &t, c == '-');
            d_rnd(r);
        } else break;
    }
}

/* hitung string ekspresi; kembalikan g_err (0 = ok) */
SU int sci_eval(const char *expr, dec *out, int deg)
{
    g_err = 0; g_depth = 0; g_deg = deg; g_p = expr;
    d_clr(out);
    if (*expr == 0) { g_err = ERR_SYNTAX; return g_err; }
    ev_expr(out);
    if (!g_err && *g_p != 0) g_err = ERR_SYNTAX;
    if (g_err) d_clr(out);
    return g_err;
}
#endif

-- m0tral (c) 2026-09-04

local lvgl = require("lvgl")

local LOGO_NAME   = "calc_logo_112.png"

local FW_TO_APP = {
    ["3.201.016"] = "mb10p_sci_3.201.016.elf",
}

local function detect_fw_version()
    os.execute("getprop ro.build.version > /tmp/device_version")
    local f = io.open("/tmp/device_version", "r")
    if not f then return nil end
    local raw = f:read("*l") or ""
    f:close()
    return (raw:match("^%s*([%d._]+)") or ""):gsub("%s+", "")
end

local fw     = detect_fw_version()
local APP_NAME = FW_TO_APP[fw]
local LOAD_ERROR = nil
if not APP_NAME then
    LOAD_ERROR = "unsupported firmware: " .. tostring(fw)
                 .. "\nadd a FW_TO_APP entry for this build"
    APP_NAME = ""
end

local MODULE_NAME = "mb10p_sci"

local APP_SRC     = SCRIPT_PATH .. APP_NAME
local APP_DST     = "/data/mb10p_com.user.sci.elf"

local LOGO_SRC    = SCRIPT_PATH .. LOGO_NAME
local LOGO_DST    = "/data/" .. LOGO_NAME

local rootbase = lvgl.Object(nil, {
    w = lvgl.HOR_RES(), h = lvgl.VER_RES(), bg_color = 0x000000,
    bg_opa = lvgl.OPA(100), border_width = 0,
})
rootbase:clear_flag(lvgl.FLAG.SCROLLABLE)
rootbase:add_flag(lvgl.FLAG.EVENT_BUBBLE)
local root = lvgl.Object(rootbase, {
    w = lvgl.HOR_RES(), h = lvgl.VER_RES(), bg_color = 0x000000,
    bg_opa = lvgl.OPA(100),
    border_width = 0, pad_all = 0, align = lvgl.ALIGN.CENTER,
})
root:clear_flag(lvgl.FLAG.SCROLLABLE)
root:add_flag(lvgl.FLAG.EVENT_BUBBLE)

local function F(n) return lvgl.Font("MiSans-Demibold", n, "normal") end
local W, G, OK, ER, OR, OFF = 0xFFFFFF, 0x8E8E93, 0x30D158, 0xFF453A, 0xFF9500, 0x555555
local function L(t, n, c, y)
    return lvgl.Label(root, { text = t, text_color = c, text_font = F(n),
        align = { type = lvgl.ALIGN.CENTER, x_ofs = 0, y_ofs = y } })
end
L("SciCalc", 38, W, -150)
L("Scientific Calculator", 20, G, -108)
local st = L(LOAD_ERROR and "Unsupported fw" or "Ready to install", 24, LOAD_ERROR and ER or G, 96)
local dt = L("fw " .. tostring(fw), 18, G, 132)
local function S(t, c) st:set { text = t, text_color = c } end
local function D(t, c) dt:set { text = t, text_color = c or G } end

local btn = lvgl.Object(root, { w = 288, h = 84, radius = 42, bg_opa = lvgl.OPA(100),
    bg_color = LOAD_ERROR and OFF or OR,
    align = { type = lvgl.ALIGN.CENTER, x_ofs = 0, y_ofs = -10 } })
btn:clear_flag(lvgl.FLAG.SCROLLABLE)
btn:add_flag(lvgl.FLAG.EVENT_BUBBLE)
btn:add_flag(lvgl.FLAG.CLICKABLE)
local bl = lvgl.Label(btn, { text = "Install", text_color = W, text_font = F(32),
    align = lvgl.ALIGN.CENTER })
local function B(t, c, on)
    bl:set { text = t }
    btn:set { bg_color = c }
    if on then btn:add_flag(lvgl.FLAG.CLICKABLE) else btn:clear_flag(lvgl.FLAG.CLICKABLE) end
end
local function fail(t, code)
    B("Retry", OR, true)
    S("Install failed", ER)
    D(t .. " " .. tostring(code), ER)
end
local function good(r) return r == true or r == 0 end

local function install()
    B("Installing...", OFF, false)
    S("Installing...", W)
    D("Do not close")
    local r = os.execute("cp " .. APP_SRC .. " " .. APP_DST)
    if not good(r) then return fail("copy", r) end
    r = os.execute("cp " .. LOGO_SRC .. " " .. LOGO_DST)
    if not good(r) then return fail("icon", r) end
    os.execute("rmmod " .. MODULE_NAME)
    r = os.execute("insmod " .. APP_DST .. " " .. MODULE_NAME)
    if not good(r) then return fail("insmod", r) end
    B("Done", OK, false)
    S("Fully installed", OK)
    local n = 5
    D("Watchface closes in 5s")
    pcall(function()
        local t
        t = lvgl.Timer { period = 1000, cb = function()
            n = n - 1
            if n > 0 then D("Watchface closes in " .. n .. "s")
            else D("Closing...") pcall(function() t:delete() end) end
        end }
    end)
end

btn:onClicked(function()
    if LOAD_ERROR then return end
    local ok, e = pcall(install)
    if not ok then fail("error", e) end
end)
if LOAD_ERROR then btn:clear_flag(lvgl.FLAG.CLICKABLE) end

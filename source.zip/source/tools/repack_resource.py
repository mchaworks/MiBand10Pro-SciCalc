#!/usr/bin/env python3
"""
repack_resource.py -- ganti isi file (lua/elf) di dalam resource.bin watchface calculator,
TANPA mengubah ukuran total tiap slot (jadi offset lain tidak bergeser).

Format yang sudah diverifikasi dari resource.bin calculator:
  tabel @0x110, 16 byte per record: [idx|0x05 type][0][offset u32][size u32]
  tiap entry @offset: [data_size u16][0][name_len u8][16 byte nol][name][data]
  size record = 20 + name_len + data_size

Pemakaian:
  python3 repack_resource.py ASLI.bin HASIL.bin SLOT=NAMA_BARU:FILE [SLOT=...]
  SLOT = nomor entry 0..3 (0=logo, 1=main.lua, 2=elf 3.101.043, 3=elf 3.201.016)
Contoh:
  python3 repack_resource.py resource.bin new.bin 1=lua/main.lua:main.lua 3=lua/mb10p_notes_3.201.016.elf:notes.elf
"""
import struct, sys

TABLE, NREC = 0x110, 4

def entries(d):
    out = []
    for i in range(NREC):
        idx, zero, off, size = struct.unpack('<IIII', d[TABLE+16*i:TABLE+16*i+16])
        assert idx == (i | 0x05000000) and zero == 0, "record %d aneh" % i
        ds = struct.unpack('<H', d[off:off+2])[0]; nl = d[off+3]
        assert d[off+2] == 0 and 20 + nl + ds == size, "header entry %d tidak cocok" % i
        name = d[off+20:off+20+nl].decode()
        out.append((off, size, name, d[off+20+nl:off+20+nl+ds]))
    return out

def build(d, repl):
    d = bytearray(d)
    ents = entries(bytes(d))
    for slot, (name, data) in repl.items():
        off, size, _, _ = ents[slot]
        nb = name.encode()
        cap = size - 20 - len(nb)
        if len(data) > cap:
            raise SystemExit("slot %d: data %d byte > kapasitas %d byte" % (slot, len(data), cap))
        pad = b"\n" if name.endswith(".lua") else b"\x00"
        body = data + pad * (cap - len(data))
        ent = struct.pack('<HBB', cap, 0, len(nb)) + b"\x00"*16 + nb + body
        assert len(ent) == size
        d[off:off+size] = ent
    return bytes(d)

if __name__ == "__main__":
    if len(sys.argv) < 4: sys.exit(__doc__)
    orig = open(sys.argv[1], 'rb').read()
    repl = {}
    for a in sys.argv[3:]:
        slot, rest = a.split('=', 1); name, path = rest.rsplit(':', 1)
        repl[int(slot)] = (name, open(path, 'rb').read())
    new = build(orig, repl)
    assert len(new) == len(orig)
    open(sys.argv[2], 'wb').write(new)
    for i, (off, size, name, data) in enumerate(entries(new)):
        print("slot %d @0x%x %5d byte  %-40s data=%d" % (i, off, size, name, len(data)))
    diff = sum(1 for a, b in zip(orig, new) if a != b)
    print("ukuran sama:", len(new), "| byte berbeda:", diff)
